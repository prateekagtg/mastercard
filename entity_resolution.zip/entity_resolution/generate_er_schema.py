from pyTigerGraph import TigerGraphConnection
import json
import sys

if (len(sys.argv) != 2):
  print('\nThis script requires exactly one additional argument in order to run (please find additioanl instructions on the README file)\n')
  exit()

if (sys.argv[1] != 'full' and sys.argv[1] != 'partial'):
  print('\nWrong argument was passed upon running this script (please find additioanl instructions on the README file)\n')
  exit()

# Read in Tigergraph DB configs
with open('./config.json', "r") as config_file:
  config = json.load(config_file)

graph_name = config['graph_name']
entity = config['entity']
same_as = config['same_as']
connected_component = config['connected_component']
entity_in_ring = config['entity_in_ring']
edges_meta = config['edges_meta']

edge_types = list(edges_meta.keys())
fuzzy_edge_types = [et for et in edge_types if edges_meta[et]['fuzzy'] == True]

discriminator_minhash_attribute = False
for et in edge_types:
  if edges_meta[et]['allow_multiple'] == True:
    discriminator_minhash_attribute = True

conn = TigerGraphConnection(
  host=config["host"],
  username=config["username"],
  password=config["password"],
  graphname = graph_name
)

token=conn.getToken(conn.createSecret())

if(conn.echo() == "Hello GSQL"):
  print(f'Connection successful to {graph_name} on {config["host"]}. Running TG version {conn.getVer()}')
else:
  print('Connection error.')



def generate_schema_full():
  job_name = 'add_to_er_graph'
  distinct_attributes_loop = ', '.join(['distinct_' + edges_meta[et]['to_vertex'].lower() + ' INT' for et in edge_types])
  vertex_creation_loop = '\n        '.join(['ADD VERTEX ' + edges_meta[et]['to_vertex'] + ' (PRIMARY_ID id STRING) WITH primary_id_as_attribute="true";' for et in edge_types])
  hash_vertex_creation_loop = '\n        '.join(['ADD VERTEX ' + edges_meta[et]['to_vertex'] + '_Hash (PRIMARY_ID id STRING) WITH primary_id_as_attribute="true";' for et in fuzzy_edge_types])
  edge_creation_loop = '\n        '.join(['ADD UNDIRECTED EDGE ' + et + ' (From ' + entity + ', To ' + edges_meta[et]['to_vertex'] + ', ' + edges_meta[et]['to_vertex'].lower() + ' STRING);' for et in edge_types])
  hash_edge_creation_loop = '\n        '.join(['ADD UNDIRECTED EDGE ' + et + '_Hash (From ' + entity + ', To ' + edges_meta[et]['to_vertex'] + '_Hash, ' + edges_meta[et]['to_vertex'].lower() + ' STRING);' for et in fuzzy_edge_types])
  if discriminator_minhash_attribute:
    hash_edge_creation_loop = '\n        '.join(['ADD UNDIRECTED EDGE ' + et + '_Hash (From ' + entity + ', To ' + edges_meta[et]['to_vertex'] + '_Hash, DISCRIMINATOR(' + edges_meta[et]['to_vertex'].lower() + ' STRING));' for et in fuzzy_edge_types])
  schema_job_string = '''
      DROP QUERY delete_all_connected_components
      DROP QUERY match_entities
      DROP QUERY unify_entities
      DROP QUERY statistics
      DROP JOB load_data_to_er_graph
      DROP JOB load_hash_to_er_graph
      DROP GRAPH {graph_name}
      CREATE GRAPH {graph_name} ()
      CREATE SCHEMA_CHANGE JOB {job_name} FOR GRAPH {graph_name} {{
        ADD VERTEX {entity} (PRIMARY_ID id STRING) WITH primary_id_as_attribute="true";
        ADD VERTEX {connected_component} (PRIMARY_ID id INT, connections_count INT, {distinct_attributes_loop}) WITH primary_id_as_attribute="true";
        {vertex_creation_loop}
        {hash_vertex_creation_loop}
        ADD UNDIRECTED EDGE {same_as} (From {entity}, To {entity}, score DOUBLE);
        ADD UNDIRECTED EDGE {entity_in_ring} (From {entity}, To {connected_component});
        {edge_creation_loop}
        {hash_edge_creation_loop}
      }}
      RUN SCHEMA_CHANGE JOB {job_name}
      DROP JOB {job_name}
    '''.format(graph_name = graph_name, job_name = job_name, entity = entity, same_as = same_as, connected_component = connected_component, entity_in_ring = entity_in_ring, distinct_attributes_loop = distinct_attributes_loop, vertex_creation_loop = vertex_creation_loop, edge_creation_loop = edge_creation_loop, hash_vertex_creation_loop = hash_vertex_creation_loop, hash_edge_creation_loop = hash_edge_creation_loop)
  # print(schema_job_string)
  results = conn.gsql(schema_job_string)
  print(results)



def generate_schema_partial():
  job_name = 'add_to_er_graph'
  distinct_attributes_loop = ', '.join(['distinct_' + edges_meta[et]['to_vertex'].lower() + ' INT' for et in edge_types])
  hash_vertex_creation_loop = '\n        '.join(['ADD VERTEX ' + edges_meta[et]['to_vertex'] + '_Hash (PRIMARY_ID id STRING) WITH primary_id_as_attribute="true";' for et in fuzzy_edge_types])
  hash_edge_creation_loop = '\n        '.join(['ADD UNDIRECTED EDGE ' + et + '_Hash (From ' + entity + ', To ' + edges_meta[et]['to_vertex'] + '_Hash, ' + edges_meta[et]['to_vertex'].lower() + ' STRING);' for et in fuzzy_edge_types])
  if discriminator_minhash_attribute:
    hash_edge_creation_loop = '\n        '.join(['ADD UNDIRECTED EDGE ' + et + '_Hash (From ' + entity + ', To ' + edges_meta[et]['to_vertex'] + '_Hash, DISCRIMINATOR(' + edges_meta[et]['to_vertex'].lower() + ' STRING));' for et in fuzzy_edge_types])
  schema_job_string = '''
      USE GRAPH {graph_name}
      CREATE SCHEMA_CHANGE JOB {job_name} FOR GRAPH {graph_name} {{
        ADD VERTEX {connected_component} (PRIMARY_ID id INT, connections_count INT, {distinct_attributes_loop}) WITH primary_id_as_attribute="true";
        {hash_vertex_creation_loop}
        ADD UNDIRECTED EDGE {same_as} (From {entity}, To {entity}, score DOUBLE);
        ADD UNDIRECTED EDGE {entity_in_ring} (From {entity}, To {connected_component});
        {hash_edge_creation_loop}
      }}
      RUN SCHEMA_CHANGE JOB {job_name}
      DROP JOB {job_name}
    '''.format(graph_name = graph_name, job_name = job_name, entity = entity, same_as = same_as, connected_component = connected_component, entity_in_ring = entity_in_ring, distinct_attributes_loop = distinct_attributes_loop, hash_vertex_creation_loop = hash_vertex_creation_loop, hash_edge_creation_loop = hash_edge_creation_loop)
  # print(schema_job_string)
  results = conn.gsql(schema_job_string)
  print(results)
  #ADD DIRECTED EDGE posted (From Person, To Post, post_date DATETIME) WITH REVERSE_EDGE="reverse_posted";



def generate_schema():
  if (sys.argv[1] == 'full'):
    generate_schema_full()
  if (sys.argv[1] == 'partial'):
    generate_schema_partial()



generate_schema()


