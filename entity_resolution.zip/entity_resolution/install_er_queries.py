from pyTigerGraph import TigerGraphConnection
import json

# Read in Tigergraph DB configs
with open('./config.json', 'r') as config_file:
  config = json.load(config_file)

graph_name = config['graph_name']

print('Connecting to Graph...')

conn = TigerGraphConnection(
  host=config['host'],
  username=config['username'],
  password=config['password'],
  graphname = graph_name
)

token=conn.getToken(conn.createSecret())

if(conn.echo() == 'Hello GSQL'):
  print(f'Connection successful to {graph_name} on {config["host"]}. Running TG version {conn.getVer()}')
else:
  print('Connection error.')

def install_entity_resolution_queries():
  query_installation_string = '''
    USE GRAPH {graph_name}
    INSTALL QUERY delete_all_connected_components
    INSTALL QUERY match_entities
    INSTALL QUERY unify_entities
    INSTALL QUERY statistics
  '''.format(graph_name = graph_name)
  # print(query_installation_string)
  results = conn.gsql(query_installation_string)
  print(results)

print('Installing queries...')
install_entity_resolution_queries()
