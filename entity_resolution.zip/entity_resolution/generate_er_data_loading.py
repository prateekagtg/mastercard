from pyTigerGraph import TigerGraphConnection
import json

# Read in Tigergraph DB configs
with open('./config.json', "r") as config_file:
  config = json.load(config_file)

graph_name = config['graph_name']
entity = config['entity']
same_as = config['same_as']
connected_component = config['connected_component']
entity_in_ring = config['entity_in_ring']
edges_meta = config['edges_meta']
edge_types = list(edges_meta.keys())

has_fuzzy = False
for et in edge_types:
  if edges_meta[et]['fuzzy'] == True:
    has_fuzzy = True

data_source_arg_name = 'data_source'
data_source = config['loading_job_meta']['data_source']
entity_id_column = config['loading_job_meta']['entity_id_column']
vertices = config['loading_job_meta']['vertices']
edges = config['loading_job_meta']['edges']
minhash_loadings = config['loading_job_meta']['minhash_loadings']

has_header = 'false'
if config['loading_job_meta']['file_has_header_row']:
  has_header = 'true'


conn = TigerGraphConnection(
  host=config["host"],
  username=config["username"],
  password=config["password"],
  graphname = graph_name
)

token=conn.getToken(conn.createSecret())

if(conn.echo() == "Hello GSQL"):
  print(f'Connection successful to {graph_name} on {config["host"]}. Running TG version {conn.getVer()}')
else:
  print('Connection error.')



def load_data_to_graph():
  
  # Create the loading job
  job_name = 'load_data_to_er_graph'
  load_vertex_loop = '\n        '.join(['LOAD ' + data_source_arg_name + ' TO VERTEX ' + v['name'] + ' VALUES(' + ', '.join(v['values']) + ') USING SEPARATOR=",", HEADER="' + has_header + '", EOL="\\n", QUOTE="double";' for v in vertices])
  load_edge_loop = '\n        '.join(['LOAD ' + data_source_arg_name + ' TO EDGE ' + e['name'] + ' VALUES(' + ', '.join(e['values']) + ') USING SEPARATOR=",", HEADER="' + has_header + '", EOL="\\n", QUOTE="double";' for e in edges])
  loading_job_string = '''
      USE GRAPH {graph_name}
      DROP JOB {job_name}
      CREATE LOADING JOB {job_name} FOR GRAPH {graph_name} {{
        DEFINE FILENAME {data_source_arg_name};
        {load_vertex_loop}
        {load_edge_loop}
      }}
    '''.format(graph_name = graph_name, job_name = job_name, entity = entity, data_source_arg_name = data_source_arg_name, load_vertex_loop = load_vertex_loop, load_edge_loop = load_edge_loop)
  # print(loading_job_string)
  results = conn.gsql(loading_job_string)
  print(results)

  # Run the loading job
  results = conn.runLoadingJobWithFile(filePath = data_source, fileTag = data_source_arg_name, jobName = job_name)
  print(json.dumps(results, indent = 2))



def load_hash_to_graph():
  
  if not has_fuzzy:
   return
  
  # Create the loading job
  job_name = 'load_hash_to_er_graph'
  load_hash_loop = ''.join(['''
        LOAD ''' + data_source_arg_name + ''' TO TEMP_TABLE ''' + m['edge'].lower() + '''_''' + str(i) + '''_table(entityid, codename, realname) VALUES(''' + entity_id_column + ''', FLATTEN (minHash(''' + m['column'] + ''',"3","10"), "|", 1), ''' + m['column'] + ''') USING SEPARATOR=",", HEADER="''' + has_header + '''", EOL="\\n";
        LOAD TEMP_TABLE ''' + m['edge'].lower() + '''_''' + str(i) + '''_table TO VERTEX ''' + m['vertex'] + ''' VALUES($"codename");
        LOAD TEMP_TABLE ''' + m['edge'].lower() + '''_''' + str(i) + '''_table TO EDGE ''' + m['edge'] + ''' VALUES($"entityid", $"codename", $"realname");
  ''' for i, m in enumerate(minhash_loadings)])
  loading_job_string = '''
      USE GRAPH {graph_name}
      DROP JOB {job_name}
      CREATE LOADING JOB {job_name} FOR GRAPH {graph_name} {{
        DEFINE FILENAME {data_source_arg_name};
        {load_hash_loop}
      }}
    '''.format(graph_name = graph_name, job_name = job_name, data_source_arg_name = data_source_arg_name, load_hash_loop = load_hash_loop)
  
  # print(loading_job_string)
  results = conn.gsql(loading_job_string)
  print(results)

  # Run the loading job
  results = conn.runLoadingJobWithFile(filePath = data_source, fileTag = data_source_arg_name, jobName = job_name)
  print(json.dumps(results, indent = 2))



def create_loading_jobs():
  load_data_to_graph()
  if has_fuzzy:
    load_hash_to_graph()



create_loading_jobs()


