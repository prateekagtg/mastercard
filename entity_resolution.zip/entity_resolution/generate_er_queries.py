from pyTigerGraph import TigerGraphConnection
import json

# Read in Tigergraph DB configs
with open('./config.json', 'r') as config_file:
  config = json.load(config_file)

graph_name = config['graph_name']
entity = config['entity']
same_as = config['same_as']
connected_component = config['connected_component']
entity_in_ring = config['entity_in_ring']
edges_meta = config['edges_meta']
bucket_size = config['bucket_size']
batch_num = config['batch_num']
threshold = config['threshold']
connections = config['connections']

edge_types = list(edges_meta.keys())
fuzzy_edge_types = [et for et in edge_types if edges_meta[et]['fuzzy'] == True]

has_fuzzy = False
for et in edge_types:
  if edges_meta[et]['fuzzy'] == True:
    has_fuzzy = True

print('Connecting to Graph...')

conn = TigerGraphConnection(
  host=config['host'],
  username=config['username'],
  password=config['password'],
  graphname = graph_name
)

token=conn.getToken(conn.createSecret())

if(conn.echo() == 'Hello GSQL'):
  print(f'Connection successful to {graph_name} on {config["host"]}. Running TG version {conn.getVer()}')
else:
  print('Connection error.')



def create_query_delete_all_connected_components():
  query = '''
  USE GRAPH {graph_name}
  DROP QUERY delete_all_connected_components
  CREATE OR REPLACE DISTRIBUTED QUERY delete_all_connected_components() {{

    start(ANY) = {{{connected_component}.*}};
    DELETE t FROM start:t;

    start = {{{entity}.*}};

    start = SELECT s
            FROM start:s - ({same_as}:e) - :t
            ACCUM DELETE(e);

    PRINT "All Connected Components Deleted!" AS result;

  }}
  '''.format(graph_name = graph_name, entity = entity, same_as = same_as, connected_component = connected_component)
  # print(query)
  results = conn.gsql(query)
  print(results)



def create_query_match_entities():
  
  def entity_fuzzy_vertex_list(et):
    return 'entity_' + edges_meta[et]['to_vertex'].lower() + '_list'
  def entity_fuzzy_vertex_map(et):
    return 'entity_' + edges_meta[et]['to_vertex'].lower() + '_map'
  def entity_fuzzy_vertex_set(et):
    return 'entity_' + edges_meta[et]['to_vertex'].lower() + '_set'
  def entity_fuzzy_vertex_sum(et):
    return 'entity_' + edges_meta[et]['to_vertex'].lower() + '_sum'
  def entity_fuzzy_vertex_max_map(et):
    return 'entity_' + edges_meta[et]['to_vertex'].lower() + '_max_map'

  query_weight_params = ', '.join(['FLOAT ' + et.lower() + '_weight = ' + str(edges_meta[et]['weight']) for et in edge_types])
  edge_type_set_string = ', '.join(['"' + et + '"' for et in edge_types]) + ''.join([', "' + et + '_Hash"' for et in fuzzy_edge_types])
  first_loop_string = ''.join(['''
                WHEN "''' + et + '''" THEN
                  t.@entity_list += s
  ''' if edges_meta[et]['fuzzy'] == False else '''
                WHEN "''' + et + '''_Hash" THEN
                  t.@''' + entity_fuzzy_vertex_list(et) + ''' += entity_fuzzy_vertex_info(s, s.@''' + entity_fuzzy_vertex_sum(et) + ''')
  ''' if edges_meta[et]['allow_multiple'] == False else '''
                WHEN "''' + et + '''_Hash" THEN
                  t.@''' + entity_fuzzy_vertex_map(et) + ''' += (s -> s.@''' + entity_fuzzy_vertex_set(et) + ''')
  ''' for et in edge_types])
  second_loop_string = ''.join(['''
                  WHEN "''' + et + '''" THEN
                    FOREACH v IN s.@entity_list DO
                      IF getvid(v) < getvid(t) THEN
                        t.@entity_map += (v->''' + et.lower() + '''_weight)
                      END
                    END
  ''' if edges_meta[et]['fuzzy'] == False else '''
                  WHEN "''' + et + '''_Hash" THEN
                    FOREACH tup IN s.@''' + entity_fuzzy_vertex_list(et) + ''' DO
                      IF getvid(tup.ver) < getvid(t) THEN
                        t.@''' + entity_fuzzy_vertex_max_map(et) + ''' += (tup.ver->''' + et.lower() + '''_weight * jaroWinklerDistance(t.@''' + entity_fuzzy_vertex_sum(et) + ''', tup.str)),
                        t.@entity_map += (tup.ver->0.0)
                      END
                    END
  ''' if edges_meta[et]['allow_multiple'] == False else '''
                  WHEN "''' + et + '''_Hash" THEN
                    FOREACH (entity, pii_set) IN s.@''' + entity_fuzzy_vertex_map(et) + ''' DO
                      IF getvid(entity) < getvid(t) THEN
                        t.@entity_map += (entity->0.0),
                        FOREACH pii IN pii_set DO
                          FOREACH other_pii IN t.@''' + entity_fuzzy_vertex_set(et) + ''' DO
                            t.@''' + entity_fuzzy_vertex_max_map(et) + ''' += (entity->(pii->''' + et.lower() + '''_weight * jaroWinklerDistance(other_pii, pii)))
                          END
                        END
                      END
                    END
  ''' for et in edge_types])
  entity_fuzzy_vertex_info = '\n    TYPEDEF TUPLE<ver VERTEX<' + entity + '>, str STRING> entity_fuzzy_vertex_info;'
  query_fuzzy_variables_1 = ''.join(['\n    ListAccum<entity_fuzzy_vertex_info> @' + entity_fuzzy_vertex_list(et) + ';'
  if edges_meta[et]['allow_multiple'] == False else '\n    MapAccum<VERTEX<' + entity + '>, SetAccum<STRING>> @' + entity_fuzzy_vertex_map(et) + ';'
  for et in fuzzy_edge_types])
  query_fuzzy_variables_2 = ''.join(['\n    SumAccum<STRING> @' + entity_fuzzy_vertex_sum(et) + ';'
  if edges_meta[et]['allow_multiple'] == False else '\n    SetAccum<STRING> @' + entity_fuzzy_vertex_set(et) + ';'
  for et in fuzzy_edge_types])
  query_fuzzy_variables_3 = ''.join(['\n    MapAccum<VERTEX<' + entity + '>, MaxAccum<FLOAT>> @' + entity_fuzzy_vertex_max_map(et) + ';'
  if edges_meta[et]['allow_multiple'] == False else '\n    MapAccum<VERTEX<' + entity + '>, MapAccum<STRING, MaxAccum<FLOAT>>> @' + entity_fuzzy_vertex_max_map(et) + ';'
  for et in fuzzy_edge_types])
  query_fuzzy_variables = '' if has_fuzzy == False else entity_fuzzy_vertex_info + query_fuzzy_variables_1 + query_fuzzy_variables_2 + query_fuzzy_variables_3
  start_fuzzy_loop = ''.join(['''
      start = SELECT s FROM start:s-(''' + et + ''':e)->:t
            ACCUM s.@''' + entity_fuzzy_vertex_sum(et) + ''' += t.id;
  ''' if edges_meta[et]['allow_multiple'] == False else '''
      start = SELECT s FROM start:s-(''' + et + ''':e)->:t
            ACCUM s.@''' + entity_fuzzy_vertex_set(et) + ''' += t.id;
  ''' for et in fuzzy_edge_types])
  full_score_loop = ''.join(['''
                  IF t.@''' + entity_fuzzy_vertex_max_map(et) + '''.get(k) > 0 THEN  
                    full_score = full_score + t.@''' + entity_fuzzy_vertex_max_map(et) + '''.get(k)
                  END,'''
  if edges_meta[et]['allow_multiple'] == False else '''
                  FOREACH (pii, value) IN t.@''' + entity_fuzzy_vertex_max_map(et) + '''.get(k) DO
                    full_score = full_score + value
                  END,'''
  for et in fuzzy_edge_types])
  full_score_initiation_and_loop = '' if has_fuzzy == False else '''FLOAT full_score = 0.0 + v,''' + full_score_loop
  full_score_mention = 'v' if has_fuzzy == False else 'full_score'
  clear_max_map_loop = ''.join(['\n                t.@' + entity_fuzzy_vertex_max_map(et) + '.clear(),' for et in fuzzy_edge_types])
  clear_list_loop = ''.join(['\n                s.@' + entity_fuzzy_vertex_list(et) + '.clear(),'
  if edges_meta[et]['allow_multiple'] == False else '\n                s.@' + entity_fuzzy_vertex_map(et) + '.clear(),'
  for et in fuzzy_edge_types])
  query = '''
  USE GRAPH {graph_name}
  DROP QUERY match_entities
  CREATE OR REPLACE DISTRIBUTED QUERY match_entities({query_weight_params}, FLOAT bucket_size = {bucket_size}, INT batch_num = {batch_num}, FLOAT threshold = {threshold}, INT connections = {connections}) {{
    {query_fuzzy_variables}
    ListAccum<VERTEX<{entity}>> @entity_list;
    MapAccum<VERTEX<{entity}>,FLOAT> @entity_map;
    SumAccum<INT> @@count;
    MaxAccum<FLOAT> @@max;
    MinAccum<FLOAT> @@min;
    AvgAccum @@avg;
    MapAccum<FLOAT, FLOAT> @@map;
    SetAccum<STRING> @@edge_type_set;

    @@edge_type_set = ({edge_type_set_string});

    all_entity = {{{entity}.*}};

    FOREACH i IN RANGE[0, batch_num-1] DO

      start = SELECT s FROM all_entity:s WHERE getvid(s)%batch_num == i;
      {start_fuzzy_loop}
      attr = SELECT t FROM start:s-(@@edge_type_set:e)->:t
            WHERE t.outdegree(@@edge_type_set) > 1 AND t.outdegree() < connections
            ACCUM
              CASE e.type
                {first_loop_string}
              END;

      start = SELECT t FROM attr:s-(@@edge_type_set:e)->{entity}:t
              ACCUM
                CASE e.type
                  {second_loop_string}
                END

              POST-ACCUM

                FOREACH (k,v) IN t.@entity_map DO
                  {full_score_initiation_and_loop}
                  @@max += {full_score_mention}, @@min += {full_score_mention}, @@avg += {full_score_mention},
                  @@map += ({full_score_mention}/bucket_size->1),
                  IF {full_score_mention} > (threshold - 0.000001) THEN
                    INSERT INTO {same_as} VALUES (t, k, {full_score_mention}),
                    @@count += 1
                  END
                END,
                {clear_max_map_loop}
                t.@entity_map.clear()
              
              POST-ACCUM
                {clear_list_loop}
                s.@entity_list.clear();

    END;

    PRINT "There are " + to_string(@@count) + " entity pairs have been matched. Matching score MAX/MIN/AVG:" + to_string(@@max) + "/" + to_string(@@min) + "/" + to_string(@@avg) + "." as tgp_vs_description;
    PRINT @@map as tgp_vs_val, "x-axis" as tgp_vs_valField, "y-axis" as tgp_vs_argField, "bar" as tgp_vs_type;

  }}
  '''.format(graph_name = graph_name, entity = entity, same_as = same_as, query_weight_params = query_weight_params, query_fuzzy_variables = query_fuzzy_variables, start_fuzzy_loop = start_fuzzy_loop, edge_type_set_string = edge_type_set_string, first_loop_string = first_loop_string, second_loop_string = second_loop_string, full_score_initiation_and_loop = full_score_initiation_and_loop, full_score_mention = full_score_mention, clear_max_map_loop = clear_max_map_loop, clear_list_loop = clear_list_loop, bucket_size = str(bucket_size), batch_num = str(batch_num), threshold = str(threshold), connections = str(connections))
  # print(query)
  results = conn.gsql(query)
  print(results)



def create_query_unify_entities():
  edge_types_string = ', '.join(['"' + et + '"' for et in edge_types])
  query = '''
  USE GRAPH {graph_name}
  DROP QUERY unify_entities
  CREATE OR REPLACE DISTRIBUTED QUERY unify_entities() {{

    MinAccum<INT> @cc_id; // Each vertex's tentative component id
    SetAccum<STRING> @@edge_types;
    @@edge_types = ({edge_types_string});

    start = {{{entity}.*}};

    # Initialize: Label each vertex with its own internal ID
    S = SELECT x
      FROM start:x
      POST-ACCUM x.@cc_id = getvid(x);

    # Propagate smaller internal IDs until no more ID changes can be done
    WHILE (S.size()>0) DO
      S = SELECT t
      FROM S:s -({same_as}:e)- :t
      ACCUM t.@cc_id += s.@cc_id // If s has smaller id than t, copy the id to t
      HAVING t.@cc_id != t.@cc_id';
    END;

    result = SELECT t
            FROM start:t
            POST-ACCUM INSERT INTO {entity_in_ring} VALUES (t, t.@cc_id);

  }}
  '''.format(graph_name = graph_name, entity = entity, same_as = same_as, entity_in_ring = entity_in_ring, edge_types_string = edge_types_string)
  # print(query)
  results = conn.gsql(query)
  print(results)



def create_query_statistics():
  
  for et in edge_types:
    edges_meta[et]['distinct_vertex_global'] = '@@distinct_' + edges_meta[et]['to_vertex'].lower()
    edges_meta[et]['connected_via_global'] = '@@connected_via_' + edges_meta[et]['to_vertex'].lower()
    edges_meta[et]['only_connected_via_global'] = '@@only_connected_via_' + edges_meta[et]['to_vertex'].lower()
    edges_meta[et]['connected_via_local'] = '@connected_via_' + edges_meta[et]['to_vertex'].lower()
    edges_meta[et]['chosen_vertex_local'] = '@chosen_' + edges_meta[et]['to_vertex'].lower() + '_vertex'

  distinct_vertex_global_loop = ', '.join([edges_meta[et]['distinct_vertex_global'] for et in edge_types])
  connected_via_global_loop = ', '.join([edges_meta[et]['connected_via_global'] for et in edge_types])
  only_connected_via_global_loop = ', '.join([edges_meta[et]['only_connected_via_global'] for et in edge_types])
  connected_via_local_loop = ', '.join([edges_meta[et]['connected_via_local'] for et in edge_types])
  chosen_vertex_local_loop = '' if has_fuzzy == False else 'MinAccum<INT> ' + ', '.join([edges_meta[et]['chosen_vertex_local'] for et in fuzzy_edge_types]) + ';'
  edge_types_string = ', '.join(['"' + et + '"' for et in edge_types])
  fuzzy_part = ''.join(['''
    fuzzy = SELECT s FROM start:s - (''' + et + ''':e) - :t
            ACCUM
              CASE e.type
                WHEN "''' + et + '''" THEN s.''' + edges_meta[et]['chosen_vertex_local'] + ''' += getvid(t)
              END;
    
    fuzzy = SELECT s FROM start:s - (''' + et + ''':e) - :t
            ACCUM 
              CASE e.type
                WHEN "''' + et + '''" THEN t.''' + edges_meta[et]['chosen_vertex_local'] + ''' += s.''' + edges_meta[et]['chosen_vertex_local'] + '''
              END;
  ''' for et in fuzzy_edge_types])
  part_one_loop = ',\n                '.join([
  'IF t.type == "' + edges_meta[et]['to_vertex'] + '" THEN ' + edges_meta[et]['distinct_vertex_global'] + ' += (comm_id->1) END'
  if edges_meta[et]['fuzzy'] == False else
  'IF t.type == "' + edges_meta[et]['to_vertex'] + '" AND t.' + edges_meta[et]['chosen_vertex_local'] + ' == getvid(t) THEN ' + edges_meta[et]['distinct_vertex_global'] + ' += (comm_id->1) END'
  for et in edge_types])
  part_two_accum_loop =  ',\n'.join(['                 IF t.type == "' + edges_meta[et]['to_vertex'] + '" THEN s.' + edges_meta[et]['connected_via_local'] + ' += true END' for et in edge_types])
  part_two_post_accum_loop =  ',\n'.join(['                 IF s.' + edges_meta[et]['connected_via_local'] + ' THEN ' + edges_meta[et]['connected_via_global'] + ' += (s.@cc_id->1) END' for et in edge_types])
  part_three_only_connected_loop =  ',\n'.join(['         IF "' + edges_meta[et]['to_vertex'] + '" IN s.@middle_type THEN ' + edges_meta[et]['only_connected_via_global'] + ' += (s.@cc_id->1) END' for et in edge_types])
  part_two_post_accum_loop =  ',\n'.join(['                 IF s.' + edges_meta[et]['connected_via_local'] + ' THEN ' + edges_meta[et]['connected_via_global'] + ' += (s.@cc_id->1) END' for et in edge_types])
  part_three_distinct_loop = ',\n                                      '.join([edges_meta[et]['distinct_vertex_global'] + '.get(t.@cc_id)' for et in edge_types])
  query = '''
  USE GRAPH {graph_name}
  DROP QUERY statistics
  CREATE OR REPLACE DISTRIBUTED QUERY statistics() {{

    MapAccum<INT, INT> @@connections_count_map, {distinct_vertex_global_loop}, {connected_via_global_loop}, {only_connected_via_global_loop};
    OrAccum {connected_via_local_loop};
    {chosen_vertex_local_loop}
    SetAccum<STRING> @middle_type;
    SetAccum<INT> @comm_ids;
    SumAccum<INT> @@total_count, @@unified_count;
    ListAccum<int> @result;
    MinAccum<INT> @cc_id; // Each vertex's tentative component id
    SetAccum<STRING> @@edge_types;
    @@edge_types = ({edge_types_string});

    start = {{{entity}.*}};

    # Initialize: Label each vertex with its own internal ID
    S = SELECT x
      FROM start:x
      POST-ACCUM x.@cc_id = getvid(x);

    # Propagate smaller internal IDs until no more ID changes can be done
    WHILE (S.size()>0) DO
      S = SELECT t
      FROM S:s -({same_as}:e)- :t
      ACCUM t.@cc_id += s.@cc_id // If s has smaller id than t, copy the id to t
      HAVING t.@cc_id != t.@cc_id';
    END;

    {fuzzy_part}
    # Calculate the first part
    part_one = SELECT s FROM start:s -(@@edge_types:e)- :t 
              
            ACCUM 
              
              t.@comm_ids += s.@cc_id

            POST-ACCUM
              
              @@connections_count_map += (s.@cc_id -> 1)

            POST-ACCUM

              FOREACH comm_id IN t.@comm_ids DO
                {part_one_loop}
              END;
/**
    part_two = SELECT s FROM start:s-(@@edge_types:e)->:t
               WHERE t.outdegree(@@edge_types) >=2 
               ACCUM 
                
                 s.@middle_type += t.type,

{part_two_accum_loop}
    
               POST-ACCUM

{part_two_post_accum_loop}
                   HAVING s.@middle_type.size() ==1; 

    part_three = SELECT s FROM part_two:s POST-ACCUM  
              
{part_three_only_connected_loop};     
*/
    start = SELECT t FROM start:t WHERE t.@cc_id == getvid(t)
    POST-ACCUM INSERT INTO {connected_component} VALUES (t.@cc_id,
                                      @@connections_count_map.get(t.@cc_id),
                                      {part_three_distinct_loop});
    
  }}
  '''.format(graph_name = graph_name, entity = entity, same_as = same_as, connected_component = connected_component, entity_in_ring = entity_in_ring, edge_types_string = edge_types_string, distinct_vertex_global_loop = distinct_vertex_global_loop, connected_via_global_loop = connected_via_global_loop, only_connected_via_global_loop = only_connected_via_global_loop, connected_via_local_loop = connected_via_local_loop, chosen_vertex_local_loop = chosen_vertex_local_loop, fuzzy_part = fuzzy_part, part_one_loop = part_one_loop, part_two_accum_loop = part_two_accum_loop, part_two_post_accum_loop = part_two_post_accum_loop, part_three_only_connected_loop = part_three_only_connected_loop, part_three_distinct_loop = part_three_distinct_loop)
  # print(query)
  results = conn.gsql(query)
  print(results)



def create_entity_resolution_queries():
  create_query_delete_all_connected_components()
  create_query_match_entities()
  create_query_unify_entities()
  create_query_statistics()



print('Generating queries...')
create_entity_resolution_queries()


