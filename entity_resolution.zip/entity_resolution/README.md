# Generating ER (Entity Resolution) Solution

## First Steps (Required)

1. Install pyTigerGraph (local):
    <pre><b>pip3 install pytigergraph</b></pre>

2. Make sure to have an available graph on GraphStudio.

3. Set the data on the config.json file according to your use case. In order to do so, please follow the guidelines within the confi.json file, and please find the config-example.json file as a reference for a complete configuration example.

4. Make sure that the user used on the config.file has the relevant access (could be modified on Access Management on GraphStuidio).

5. Some UDFs (user-defined function) such as "jaroWinklerDistance" are required in order to be able to save the queries (because the queries are using these functions). These functions could be found inside the ExprFunctions.hpp file and the ExprUtil.hpp file that are included here in this folder. Please make sure that the contents of both files are included on the matching files of your TigerGraph environment. Also, please find the instructions in the following link on how to upload UDFs (user-defined functions) as there are two optional ways to do so (either with github, or by uploading the files manually):
https://docs.tigergraph.com/gsql-ref/current/querying/func/query-user-defined-functions#_upload_udfs

6. If your solution includes fuzzy matches, make sure to have the "minHash" function available in your TokenBank.cpp file (an example of such file is included here in this folder). Please find the instructions in the following link on how to add a User-defined Token Function (same as with UDFs, there are two optional ways to do so, either with github, or by uploading the files manually):
https://docs.tigergraph.com/gsql-ref/current/ddl-and-loading/add-token-function#_use_github_to_store_token_functions

## Generating the Schema

Please choose one of 3 options in order to set up the graph schema.

### Option 1 - Fully Manually

Create the schema manually and make sure it has the following components:

- A vertex for the main entity.
- Vertices for all the relevant entities that are connected to the main entity (all the entities you wish to use in order to perform exact/fuzzy matches).
- Vertex/Edge for each hashed value which will be used for fuzzy match. For example, if it is required to perform fuzzy match on a vertex called "First_Name" (which is connected to the main entity via an edge called "Entity_Has_First_Name), then it is also required that the schema will include a vertex called "First_Name_Hash" that is connected to the main entity via an edge called "Entity_Has_First_Name_Hash".
- The edges between those entities and the main entity.
- An edge between the main entity and itself (you can name this edge "Same_As" for example).
- The "Same_As" edge needs to have an attribute of type DOUBLE (you can name it "score" for example).
- A vertex that will serve as a connected component (you can name it "Connected_Component" for example).
- An edge between the main entity and the connected component vertex (you can name this edge "Entity_In_Ring" for example).
- Your connected component vertex needs to have a primary ID of type INT as first attribute, a counter attribute of type INT (you can name it "connections_count" for example), and another additional attribute of type INT for each exact/fuzzy match.
- Make sure that the order of the attributes of the connected component matches the order of the matching edges on the config.json file.

### Option 2 - Full Automation

Run the following script, which completely deletes your current graph schema and generates a complete new schema (based on the config.json file).

Warning: before running this script, be mindful that your current schema on GraphStudio will be lost.

The following command is useful in case you don't care about losing the current schema or if you did't set up the schema yet.

<pre><b>python3 generate_er_schema.py full</b></pre>

### Option 3 - Partial Automation

Run a script that adds the next components to the graph schema:

- The connected component vertex
- The edge between the main entity and the connected component vertex
- The edge between the main entity and itself
- The hashed vertices and edges (for fuzzy matches)

This approach is great if everything else is already set up.

<pre><b>python3 generate_er_schema.py partial</b></pre>

## Loading the Data to the Graph

1. Make sure your data source (CSV file) is included in this folder. Also, if your TigerGraph version is below 3.9, make sure your CSV file does not have a header row (remove the header row if you have one). There is an example of such file in this folder, it's named "1k_customers_no_header.csv" and can be deleted or ignored if you put your own data source in this folder.

2. Run the following script to generate the loading jobs (both regular data loading and minHash loading):
    <pre><b>python3 generate_er_data_loading.py</b></pre>

## Generating the Queries

1. Run the following script to generate the Entity Resolution queries:
    <pre><b>python3 generate_er_queries.py</b></pre>

2. The queries should now appear on your GraphStudio environment.

3. (Optional) Please feel free to uncomment the commented part of the "statistics" query in case this logic is needed, or leave it as is if not. Also, this entire query is optional and might not be needed for your use case at all.

## Installing the queries

Make sure to install the saved queries on GraphStudio (to enable them to run), or simply run the following command which will automatically install the queries for you:

<pre><b>python3 install_er_queries.py</b></pre>

## Running the Queries

The sequence to run these queries (after they are installed) is as follows:

1. delete_all_connected_components
2. match_entities
3. unify_entities
4. statistics (this query is optional, and could be ran either before or after "unify_entities")

## About the Queries

All 4 queries make changes to the graph (delete/create vertices and edges), and here is some additional information about each query and its results:

- delete_all_connected_components – Deletes all the "Connected_Component" vertices from the graph in order to reset the Entity Resolution process.
- match_entities – Accumulates values based on matching individual attributes between two main Entity vertices. If the accumulated value is greater than the defined threshold, then the query creates a "Same_As" edge between the two vertices with the accumulated values saved as the weight on this edge. The general recommended values for the query parameters "bucket_size", "batch_num", "threshold", and "connections" are the values in the initial config file, but it might change based on your use case. Please note that these values are used as the default values of the "match_entities" query input parameters, but could be set to anything you need when you run this query in practice.
- unify_entities – Completes the Entity Resolution process by creating "Entity_In_Ring" edges between each main Entity and its matching "Connected_Component" in order to achieve rings of similar entities. Please note that nothing special would be printed as a result of running this query, as it simply completes the ER process.
- statistics – Saves the relevant attributes on the "Connected_Component" vertices. The logic in this query was originally a part of the "unify_entities" query, but it was moved to this new "statistics" query in order to make the "unify_entities" cleaner and more performant.